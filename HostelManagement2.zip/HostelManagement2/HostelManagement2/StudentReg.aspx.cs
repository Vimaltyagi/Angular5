﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace HostelManagement2
{
    public partial class StudentReg : System.Web.UI.Page
    {
        SqlConnection mycon = new SqlConnection(@"Data Source=.;initial catalog=HostelMgmt;Integrated Security=true");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string insertqry = "insert into StudentReg(UserName,Password,Name,Surname,Age,Address,College,Course) values ('" +usertxt.Text+ "','" +passtxt.Text+ "','" +nametxt.Text + "','" + surtxt.Text+ "','" + agetxt.Text + "','" + addtxt.Text+ "','" + DropDownList1.SelectedItem.Text + "','" + DropDownList2.SelectedItem.Text + "')";
            SqlCommand mycmd = new SqlCommand(insertqry, mycon);
            mycon.Open();
            mycmd.ExecuteNonQuery();
            mycon.Close();
            Response.Write("data saved succssefully......");
            Response.Redirect("NoticeBoard.aspx");



        }
    }
}