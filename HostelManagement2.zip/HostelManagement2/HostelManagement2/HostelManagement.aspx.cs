﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace HostelManagement2
{
    public partial class HostelManagement : System.Web.UI.Page
    {
        SqlConnection mycon = new SqlConnection(@"Data Source=.;initial catalog=HostelMgmt;Integrated Security=true");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string insertqry = "insert into hostelvalue(HostelType,RoomType) values ('" + hostelddl.SelectedItem.Text + "','" + roomddl.SelectedItem.Text + "')";
            SqlCommand mycmd = new SqlCommand(insertqry, mycon);
            mycon.Open();
            mycmd.ExecuteNonQuery();
            mycon.Close();
            Response.Write("data saved succssefully......");
            Response.Redirect("Home.aspx");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}