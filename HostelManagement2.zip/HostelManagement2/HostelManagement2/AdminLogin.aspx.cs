﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace HostelManagement2
{
    public partial class UserLogin : System.Web.UI.Page
    {
        string StrCon = "Data Source=.;Initial Catalog=HostelMgmt;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginView1_ViewChanged(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          if(admtxt.Text!=string.Empty && admpass.Text!=string.Empty)
          {
              Response.Redirect("Home.aspx");

          }

            }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("mainhome.aspx");
        }
        }
    }
