﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace HostelManagement2
{
    public partial class StudentRecord : System.Web.UI.Page
    {
        string StrCon = @"Data Source=DESKTOP-LMGV632;Initial Catalog=HostelMgmt;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection SqlCon = new SqlConnection(StrCon);
            string Query = "Select UserName,Age,Address,College,Course from StudentReg where Name='" + TextBoxName.Text + "' and Surname='" + TextBoxSName.Text + "'";
                SqlCommand Sqlcomm = new SqlCommand(Query, SqlCon);
                SqlCon.Open();
                SqlDataReader dr;
                dr = Sqlcomm.ExecuteReader();
                 GridView1.DataSource = dr;
                 GridView1.DataBind();
                SqlCon.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("RecordUpdation.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("RecordUpdation.aspx");

        }
    }
}