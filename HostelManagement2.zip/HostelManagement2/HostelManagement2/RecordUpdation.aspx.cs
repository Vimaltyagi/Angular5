﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace HostelManagement2
{
    public partial class STURecord : System.Web.UI.Page
    {
        SqlConnection mycon = new SqlConnection(@"Data Source=.;initial catalog=HostelMgmt;Integrated Security=true");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String updateqry="update StudentReg set Name='"+txtnameup.Text+"',Surname='"+txtsurnameup.Text+"',Age='"+txtageup.Text+"',Address='"+txtaddup.Text+"',College='"+ddlcollegeup.SelectedItem.Text+"',Course='"+ddlcourseup.SelectedItem.Text+"' where UserName='"+txtuserup.Text+"' ";
            SqlCommand mycmd=new SqlCommand(updateqry,mycon);
            mycon.Open();
            int res=mycmd.ExecuteNonQuery();
            mycon.Close();
            if (res>0)
            {
                lblmsg.Text="record update successfully...";
                
            }
            else
            {
                lblmsg.Text="record updation failed!!";

            }
           
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            String dltqry = "delete from StudentReg where UserName='"+txtuserup.Text+"'";
            SqlCommand mycmd = new SqlCommand(dltqry, mycon);
            mycon.Open();
            int res = mycmd.ExecuteNonQuery();
            mycon.Close();
            if(res>0)
            {
                lblmsg.Text="data deleted succsessfully...";
            }
            else
            {
                lblmsg.Text = "No record delete!!";

            }
        }

        }

      
    }
